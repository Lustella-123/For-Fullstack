package homework.fourweek;

public abstract class AbstractOperation {
    public abstract double operate(int firstNumber, int secondNumber);
}